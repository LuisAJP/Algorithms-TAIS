
// NOMBRE Y APELLIDOS

// comentario sobre la solución, incluyendo el análisis del coste

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

#include "Grafo.h"

// esta es la clase que resuelve el problema  COMPLÉTALA
class NodoLejano {
public:
   NodoLejano( /* parametros */ ) {
      
   }
   
   int inalcanzables() const {
      
   }
private:
   /* atributos */
};

bool resuelveCaso() {
   
   int V, E;
   cin >> V >> E;
   if (!cin)
      return false;
   
   Grafo G(V);
   int u,v;
   for (int i = 0; i < E; ++i) {
      cin >> u >> v;
      G.ponArista(u-1, v-1);
   }
   
   int K; // número de preguntas
   cin >> K;
   while (K--) {
      int origen, TTL;
      cin >> origen >> TTL;
      --origen;
      
      NodoLejano nl( /* argumentos */ );
      cout <<  nl.inalcanzables() << "\n";
   }
   cout << "---\n";
   return true;
   
}
int main() {
   // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
   std::ifstream in("casos.txt");
   auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

   // Resolvemos
   while (resuelveCaso());
   
   // para dejar todo como estaba al principio
#ifndef DOMJUDGE
   std::cin.rdbuf(cinbuf);
   system("PAUSE");
#endif
   return 0;
}
