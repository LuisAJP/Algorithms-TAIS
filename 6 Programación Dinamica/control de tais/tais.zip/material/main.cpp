
// NOMBRE Y APELLIDOS

// comentario sobre la solución, incluyendo la recurrencia y
// el análisis del coste tanto en tiempo como en espacio adicional

#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;


bool resuelveCaso() {
   
   string palabra;
   cin >> palabra;
   if (!cin)
      return false;
   
   // resolver el problema (posiblemente utilizando otras funciones o clases)
   
   // escribir la respuesta
   
   return true;
}
int main() {
   // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
   std::ifstream in("casos.txt");
   auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

   // Resolvemos
   while (resuelveCaso());
   
   // para dejar todo como estaba al principio
#ifndef DOMJUDGE
   std::cin.rdbuf(cinbuf);
   system("PAUSE");
#endif
   return 0;
}
